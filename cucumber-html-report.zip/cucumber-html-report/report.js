$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("test.feature");
formatter.feature({
  "line": 2,
  "name": "Test My Store web site",
  "description": "",
  "id": "test-my-store-web-site",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 4,
  "name": "As a user, he can select category and add product to cart",
  "description": "",
  "id": "test-my-store-web-site;as-a-user,-he-can-select-category-and-add-product-to-cart",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 5,
  "name": "user navigate to \"http://automationpractice.com\"",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "user click \u003ccategory\u003e category",
  "keyword": "And "
});
formatter.step({
  "line": 7,
  "name": "user click \u003csubcategory\u003e subcategory",
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "user click \u003cdressname\u003e product",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "user click \u0027Add to cart\u0027 button",
  "keyword": "When "
});
formatter.step({
  "line": 10,
  "name": "cart page is displayed",
  "keyword": "Then "
});
formatter.step({
  "line": 11,
  "name": "verify quantity is \u003cquantity\u003e",
  "keyword": "And "
});
formatter.step({
  "line": 12,
  "name": "verify product title is \u003ctitle\u003e",
  "keyword": "And "
});
formatter.step({
  "line": 13,
  "name": "verify price is \u003cprice\u003e",
  "keyword": "And "
});
formatter.examples({
  "line": 15,
  "name": "",
  "description": "",
  "id": "test-my-store-web-site;as-a-user,-he-can-select-category-and-add-product-to-cart;",
  "rows": [
    {
      "cells": [
        "category",
        "subcategory",
        "dressname",
        "quantity",
        "title",
        "price"
      ],
      "line": 16,
      "id": "test-my-store-web-site;as-a-user,-he-can-select-category-and-add-product-to-cart;;1"
    },
    {
      "cells": [
        "Dresses",
        "Summer Dresses",
        "Printed Chiffon Dress",
        "1",
        "Printed Chiffon Dress",
        "$16.40"
      ],
      "line": 17,
      "id": "test-my-store-web-site;as-a-user,-he-can-select-category-and-add-product-to-cart;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.before({
  "duration": 28577067400,
  "status": "passed"
});
formatter.scenario({
  "line": 17,
  "name": "As a user, he can select category and add product to cart",
  "description": "",
  "id": "test-my-store-web-site;as-a-user,-he-can-select-category-and-add-product-to-cart;;2",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 5,
  "name": "user navigate to \"http://automationpractice.com\"",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "user click Dresses category",
  "matchedColumns": [
    0
  ],
  "keyword": "And "
});
formatter.step({
  "line": 7,
  "name": "user click Summer Dresses subcategory",
  "matchedColumns": [
    1
  ],
  "keyword": "And "
});
formatter.step({
  "line": 8,
  "name": "user click Printed Chiffon Dress product",
  "matchedColumns": [
    2
  ],
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "user click \u0027Add to cart\u0027 button",
  "keyword": "When "
});
formatter.step({
  "line": 10,
  "name": "cart page is displayed",
  "keyword": "Then "
});
formatter.step({
  "line": 11,
  "name": "verify quantity is 1",
  "matchedColumns": [
    3
  ],
  "keyword": "And "
});
formatter.step({
  "line": 12,
  "name": "verify product title is Printed Chiffon Dress",
  "matchedColumns": [
    4
  ],
  "keyword": "And "
});
formatter.step({
  "line": 13,
  "name": "verify price is $16.40",
  "matchedColumns": [
    5
  ],
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "http://automationpractice.com",
      "offset": 18
    }
  ],
  "location": "HomeSteps.navigate(String)"
});
formatter.result({
  "duration": 13539015063,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Dresses",
      "offset": 11
    }
  ],
  "location": "HomeSteps.clickDresses(String)"
});
formatter.result({
  "duration": 5585783771,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Summer Dresses",
      "offset": 11
    }
  ],
  "location": "HomeSteps.clickSubCategory(String)"
});
formatter.result({
  "duration": 4887253724,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Printed Chiffon Dress",
      "offset": 11
    }
  ],
  "location": "HomeSteps.hoverOnCategory(String)"
});
formatter.result({
  "duration": 167413858,
  "status": "passed"
});
formatter.match({
  "location": "HomeSteps.addToCart()"
});
formatter.result({
  "duration": 132902980,
  "status": "passed"
});
formatter.match({
  "location": "HomeSteps.verifyCartPageDisplayed()"
});
formatter.result({
  "duration": 1728076415,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "1",
      "offset": 19
    }
  ],
  "location": "HomeSteps.verifyQuantity(String)"
});
formatter.result({
  "duration": 126236252,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Printed Chiffon Dress",
      "offset": 24
    }
  ],
  "location": "HomeSteps.verifyTitle(String)"
});
formatter.result({
  "duration": 65187270,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "$16.40",
      "offset": 16
    }
  ],
  "location": "HomeSteps.verifyTotal(String)"
});
formatter.result({
  "duration": 76072342,
  "status": "passed"
});
formatter.after({
  "duration": 2522948920,
  "status": "passed"
});
});