package com.test.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SubCategoryPage extends PageObject{

    private WebElement subcategory;

    public SubCategoryPage(WebDriver driver){
        super(driver);

    }

    public void clickSubCategory(String dress){

        this.subcategory = driver.findElement(By.xpath("//a[@title='"+dress+"' and @class='img']"));
        this.subcategory.click();
    }
}
