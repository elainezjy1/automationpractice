package com.test.pages;

import org.openqa.selenium.WebDriver;

public class HomePage extends PageObject {
    public HomePage(WebDriver driver) {
        super(driver);
    }

    public MegamenuPage megaMenu(){
        MegamenuPage page =  new MegamenuPage(this.driver);
        return page;
    }

    public SubCategoryPage subCategoryPage(){
        SubCategoryPage page =  new SubCategoryPage(this.driver);
        return page;
    }

    public ProductPage productPage(String dress){
        ProductPage page =  new ProductPage(this.driver, dress);
        return page;
    }
}
