package mystore;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.After;
import org.junit.Before;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = "classpath:test.feature",
        glue = {"com.test.definition"}
        //plugin = {"html:target/cucumber-html-report"}
        )

public class MyTest {

}
