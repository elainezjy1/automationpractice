package mystore;

import com.test.definition.BrowserFactory;
import org.junit.After;
import org.junit.Test;
import org.openqa.selenium.WebDriver;

public class MyTest2 {
    WebDriver driver;
    @Test
    public void test(){
        driver = BrowserFactory.startBrowser("chrome", "https://www.google.com");
    }

    @After
    public void tearDown(){
        driver.close();
    }
}
