package mystore;

import static org.junit.Assert.assertTrue;

import mystore.automation.CategoryPage;
import mystore.automation.LayerCartPage;
import mystore.automation.MegamenuPage;
import mystore.automation.SubCategoryPage;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class AppTest 
{
    protected static WebDriver driver;
    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue()
    {
        assertTrue( true );
    }

    @BeforeClass
     public static void startWebDriver() {
        System.setProperty("webdriver.chrome.driver",
                "C:\\Users\\Administrator\\chromedriver_win32\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.navigate().to("http://automationpractice.com/");
        //WebElement element = driver.findElements(By.xpath("//ul[contains(@class,'menu-content')]//a[@title='Dresses' and @class='sf-with-ul']")).get(1);
        //System.out.println("Stop");
    }

    @Test
    public void test1 () {
        MegamenuPage menuPage = (new MegamenuPage(driver));
        menuPage.clickDresses();

        SubCategoryPage subCategoryPage = (new SubCategoryPage(driver, "Summer Dresses"));
        subCategoryPage.clickSubCategory();

        LayerCartPage cartPage = (new CategoryPage(driver, "Printed Summer Dress")).addToCart();
        cartPage.verifyQuantity("1");
        cartPage.verifyTitle("Printed Summer Dress");
        cartPage.verifyTotal("$28.98");

    }

    @After
    public void cleanUp(){
        driver.manage().deleteAllCookies();
    }

    @AfterClass
    public static void tearDown(){
        driver.close();
    }
}
