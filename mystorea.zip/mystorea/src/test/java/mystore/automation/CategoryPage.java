package mystore.automation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class CategoryPage extends PageObject {
    private String selectedDress;
    private WebElement categoryItem;

    private WebElement addtoCartButton;

    public CategoryPage(WebDriver driver, String dress){
        super(driver);
        this.categoryItem = driver.findElements(By.xpath("//div[@class='product-container' and descendant::a[@title='"+dress+"']]")).get(0);
        this.addtoCartButton = driver.findElement(By.xpath("//div[@class='product-container' and descendant::a[@title='"+dress+"']]//div[@class='right-block']//div[@class='button-container']//a[contains(@class, 'ajax_add_to_cart_button')]"));
    }

    public void hoverOnCategory(){
        this.categoryItem.click();
    }

    public LayerCartPage addToCart(){
        hoverOnCategory();
        this.addtoCartButton.click();
        return new LayerCartPage(this.driver);

    }
}
