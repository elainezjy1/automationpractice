package mystore.automation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SubCategoryPage extends PageObject {
    private String selectedDress;
    private WebElement subcategory;

    public SubCategoryPage(WebDriver driver, String dress){
        super(driver);
        this.subcategory = driver.findElement(By.xpath("//a[@title='"+dress+"' and @class='img']"));
    }

    public void clickSubCategory(){
        this.subcategory.click();
    }
}
